#ifndef __NV_TIME_H__
#define __NV_TIME_H__

#include "conftest.h"
#include <linux/time.h>

#if defined(NV_LINUX_KTIME_H_PRESENT)
#include <linux/ktime.h>
#endif

static inline void nv_gettimeofday(struct timeval *tv)
{
#ifdef NV_DO_GETTIMEOFDAY_PRESENT
    do_gettimeofday(tv);
#else
    struct timespec64 now;

    ktime_get_real_ts64(&now);
    tv->tv_sec = now.tv_sec;
    tv->tv_usec = now.tv_nsec/1000;
#endif
}

#endif
