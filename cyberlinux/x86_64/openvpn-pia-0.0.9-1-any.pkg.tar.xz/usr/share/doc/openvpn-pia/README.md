# openvpn-pia
Private Internet Access OpenVPN automation and UI

## Features
* Machine wide traffic redirect over the VPN
* Select application traffic redirects over the VPN
* Killswitch for VPN disconnects for select applications
* System tray icon indicator as to the current VPN status 
* OpenVPN configuration such as username/password configuration
* Selectable list of VPN server access points to use

## Licensing
All flag icons were taken from https://www.iconfinder.com/iconsets/142-mini-country-flags-16x16px
and are leveraging a ***Free for commercial use*** license
