# -*- encoding: utf-8 -*-
# stub: nub 0.0.136 ruby lib

Gem::Specification.new do |s|
  s.name = "nub".freeze
  s.version = "0.0.136"

  s.required_rubygems_version = Gem::Requirement.new(">= 0".freeze) if s.respond_to? :required_rubygems_version=
  s.require_paths = ["lib".freeze]
  s.authors = ["Patrick Crummett".freeze]
  s.date = "2018-08-28"
  s.homepage = "https://github.com/phR0ze/ruby-nub".freeze
  s.licenses = ["MIT".freeze]
  s.rubygems_version = "2.7.7".freeze
  s.summary = "Collection of useful utilities".freeze

  s.installed_by_version = "2.7.7" if s.respond_to? :installed_by_version

  if s.respond_to? :specification_version then
    s.specification_version = 4

    if Gem::Version.new(Gem::VERSION) >= Gem::Version.new('1.2.0') then
      s.add_runtime_dependency(%q<colorize>.freeze, ["~> 0.8.1"])
      s.add_development_dependency(%q<minitest>.freeze, ["~> 5.11.3"])
      s.add_development_dependency(%q<coveralls>.freeze, ["~> 0.8.22"])
      s.add_development_dependency(%q<bundler>.freeze, ["~> 1.16"])
      s.add_development_dependency(%q<rake>.freeze, ["~> 12.0"])
    else
      s.add_dependency(%q<colorize>.freeze, ["~> 0.8.1"])
      s.add_dependency(%q<minitest>.freeze, ["~> 5.11.3"])
      s.add_dependency(%q<coveralls>.freeze, ["~> 0.8.22"])
      s.add_dependency(%q<bundler>.freeze, ["~> 1.16"])
      s.add_dependency(%q<rake>.freeze, ["~> 12.0"])
    end
  else
    s.add_dependency(%q<colorize>.freeze, ["~> 0.8.1"])
    s.add_dependency(%q<minitest>.freeze, ["~> 5.11.3"])
    s.add_dependency(%q<coveralls>.freeze, ["~> 0.8.22"])
    s.add_dependency(%q<bundler>.freeze, ["~> 1.16"])
    s.add_dependency(%q<rake>.freeze, ["~> 12.0"])
  end
end
